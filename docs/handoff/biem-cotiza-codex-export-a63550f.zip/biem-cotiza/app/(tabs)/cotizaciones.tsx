import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { router, useLocalSearchParams } from "expo-router";
import { useMemo, useState } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { BiemScreen, IconButton, PrimaryButton, SectionTitle, Surface, Tag, ValueRow, biemColors } from "@/components/biem-ui";
import { asNumber, formatDate, formatMoney, isoDateFromNow } from "@/lib/biem/finance";
import { type Client, type Product, type Quote, type QuoteItem, useBiem } from "@/lib/biem/store";

export default function QuotesScreen() {
  const { edit } = useLocalSearchParams<{ edit?: string }>();
  const { business, clients, products, quotes, createQuote, updateQuote, pendingQuoteProductId, setPendingQuoteProduct, updateQuoteStatus } = useBiem();
  const [clientId, setClientId] = useState("");
  const [productId, setProductId] = useState(products[0]?.id ?? "");
  const [quantity, setQuantity] = useState(1);
  const [discount, setDiscount] = useState(0);
  const [items, setItems] = useState<QuoteItem[]>([]);
  const [manualOpen, setManualOpen] = useState(false);
  const [manualName, setManualName] = useState("");
  const [manualPrice, setManualPrice] = useState("");
  const [manualQuantity, setManualQuantity] = useState("1");
  const [manualTax, setManualTax] = useState(0);
  const [latestQuote, setLatestQuote] = useState<Quote | null>(null);
  const [feedback, setFeedback] = useState("");
  const [exporting, setExporting] = useState(false);

  const editSource = quotes.find((quote) => quote.id === edit);
  const transferredProduct = products.find((item) => item.id === pendingQuoteProductId);
  const selectedClientId = editSource?.clientId ?? clientId;
  const selectedDiscount = editSource?.discount ?? discount;
  const baseItems = editSource?.items ?? items;
  const product = transferredProduct ?? products.find((item) => item.id === productId) ?? products[0];
  const draftItems = useMemo(() => {
    if (!transferredProduct || baseItems.some((item) => item.productId === transferredProduct.id)) return baseItems;
    return [...baseItems, quoteItemFromProduct(transferredProduct, 1)];
  }, [baseItems, transferredProduct]);
  const client = clients.find((item) => item.id === selectedClientId);
  const totals = useMemo(() => quoteTotals(draftItems, selectedDiscount), [draftItems, selectedDiscount]);
  const documentQuote = latestQuote ?? editSource ?? null;

  function materializeEdit() {
    if (!editSource) return;
    setItems(editSource.items);
    setClientId(editSource.clientId ?? "");
    setDiscount(editSource.discount);
    router.setParams({ edit: undefined });
  }

  function clearTransfer() { if (pendingQuoteProductId) setPendingQuoteProduct(null); }

  function addSelectedProduct() {
    materializeEdit();
    if (!product) return;
    const currentItems = editSource?.items ?? draftItems;
    const existing = currentItems.find((item) => item.productId === product.id);
    setItems(existing ? currentItems.map((item) => item.productId === product.id ? { ...item, quantity: item.quantity + quantity } : item) : [...currentItems, quoteItemFromProduct(product, quantity)]);
    clearTransfer();
    setFeedback(`Añadiste “${product.name}” a la cotización.`);
  }

  function addManualItem() {
    const cleanName = manualName.trim();
    const price = asNumber(manualPrice);
    const count = Math.max(1, Number(manualQuantity) || 1);
    if (!cleanName || !price) { setFeedback("Escribe una descripción y un precio para añadir el ítem."); return; }
    materializeEdit();
    const currentItems = editSource?.items ?? draftItems;
    setItems([...currentItems, { productId: `manual-${Date.now()}`, name: cleanName, quantity: count, unit: "unidad", unitPrice: price, taxRate: manualTax, source: "manual" }]);
    setManualName(""); setManualPrice(""); setManualQuantity("1"); setManualTax(0); setManualOpen(false); clearTransfer(); setFeedback("Ítem manual añadido sin guardarlo en el catálogo.");
  }

  function removeItem(productIdToRemove: string) {
    materializeEdit();
    setItems(draftItems.filter((item) => item.productId !== productIdToRemove));
    clearTransfer();
  }

  function makeQuote() {
    if (!draftItems.length) { setFeedback("Añade al menos un producto o servicio para guardar la cotización."); return; }
    if (editSource) {
      const updated = updateQuote(editSource.id, { clientId: selectedClientId || undefined, clientName: client?.company || client?.name || undefined, title: draftItems.length === 1 ? draftItems[0].name : `${draftItems[0].name} y ${draftItems.length - 1} más`, items: draftItems, discount: selectedDiscount, validUntil: isoDateFromNow(business.validityDays), conditions: business.conditions });
      if (updated) { setItems(draftItems); setPendingQuoteProduct(null); setLatestQuote(updated); router.setParams({ edit: undefined }); setFeedback(`${updated.number} fue actualizada.`); }
      return;
    }
    const quote = createQuote({ clientId: selectedClientId || undefined, clientName: client?.company || client?.name || undefined, title: draftItems.length === 1 ? draftItems[0].name : `${draftItems[0].name} y ${draftItems.length - 1} más`, items: draftItems, discount: selectedDiscount, validUntil: isoDateFromNow(business.validityDays), conditions: business.conditions });
    setItems(draftItems); setPendingQuoteProduct(null); setLatestQuote(quote); router.setParams({ edit: undefined }); setFeedback(`${quote.number} se guardó como borrador.`);
  }

  async function exportPdf(share = false) {
    if (!documentQuote) return;
    setExporting(true);
    try {
      const html = quoteHtml(documentQuote, client, business);
      if (Platform.OS === "web") {
        const browserWindow = globalThis as unknown as { open?: (url?: string, target?: string, features?: string) => { document: { write: (markup: string) => void; close: () => void }; focus: () => void; print: () => void } | null; navigator?: { share?: (data: { title: string; text: string; url?: string }) => Promise<void> }; location?: { href?: string } };
        if (share && browserWindow.navigator?.share) {
          await browserWindow.navigator.share({ title: `Cotización ${documentQuote.number}`, text: `Propuesta de ${business.name}: ${formatMoney(quoteTotals(documentQuote.items, documentQuote.discount).total)}.`, url: browserWindow.location?.href });
          setFeedback("Se abrió el selector del navegador para compartir la propuesta.");
          return;
        }
        const printWindow = browserWindow.open?.("", "_blank", "width=760,height=900");
        if (printWindow) { printWindow.document.write(html); printWindow.document.close(); printWindow.focus(); printWindow.print(); setFeedback(share ? "Guarda el PDF desde la impresión y compártelo desde tu dispositivo." : "Se abrió la vista de impresión para guardar el PDF."); }
        return;
      }
      const { uri } = await Print.printToFileAsync({ html });
      if (share && (await Sharing.isAvailableAsync())) { await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: "Compartir cotización BIEM" }); setFeedback("PDF listo para compartir."); } else setFeedback("PDF generado y guardado en el dispositivo.");
    } catch { setFeedback("No fue posible generar el PDF. Inténtalo de nuevo."); } finally { setExporting(false); }
  }

  return <BiemScreen><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={quoteStyles.content}>
    <View style={quoteStyles.header}><View><Text style={quoteStyles.eyebrow}>{editSource ? "EDITANDO PROPUESTA" : "COTIZACIÓN RÁPIDA"}</Text><Text style={quoteStyles.title}>{editSource ? editSource.number : "Nueva cotización"}</Text></View><IconButton icon="close" label="Limpiar cotización" onPress={() => { setItems([]); setClientId(""); setLatestQuote(null); setPendingQuoteProduct(null); router.setParams({ edit: undefined }); }} /></View>
    <Text style={quoteStyles.lead}>Agrega lo que vas a vender y genera el documento. Cliente y catálogo son opcionales.</Text>
    <Surface style={quoteStyles.quickNote}><MaterialCommunityIcons name="flash-outline" size={18} color={biemColors.cyan} /><Text style={quoteStyles.quickNoteText}><Text style={quoteStyles.quickNoteStrong}>Flujo rápido:</Text> entrar → agregar ítems → generar → compartir.</Text></Surface>

    <Surface style={quoteStyles.formCard}><SectionTitle title="Cliente" action={<Tag label="OPCIONAL" tone="muted" />} /><Pressable onPress={() => { materializeEdit(); setClientId(""); }} style={[quoteStyles.clientOption, !selectedClientId && quoteStyles.clientOptionSelected]}><View style={quoteStyles.clientAvatar}><MaterialCommunityIcons name="account-question-outline" size={18} color={biemColors.cyan} /></View><View style={quoteStyles.clientCopy}><Text style={quoteStyles.clientCompany}>Cliente por definir</Text><Text style={quoteStyles.clientMeta}>Puedes agregar sus datos después</Text></View>{!selectedClientId ? <MaterialCommunityIcons name="check-circle" size={20} color={biemColors.cyan} /> : null}</Pressable><View style={quoteStyles.choiceStack}>{clients.map((item) => <Pressable key={item.id} onPress={() => { materializeEdit(); setClientId(item.id); }} style={[quoteStyles.clientOption, selectedClientId === item.id && quoteStyles.clientOptionSelected]}><View style={quoteStyles.clientAvatar}><Text style={quoteStyles.clientAvatarText}>{(item.company || item.name).slice(0, 1)}</Text></View><View style={quoteStyles.clientCopy}><Text style={quoteStyles.clientCompany}>{item.company || item.name}</Text><Text style={quoteStyles.clientMeta}>{item.name} · {item.email || "sin correo"}</Text></View>{selectedClientId === item.id ? <MaterialCommunityIcons name="check-circle" size={20} color={biemColors.cyan} /> : null}</Pressable>)}</View></Surface>

    <Surface style={quoteStyles.formCard}><SectionTitle title="Agrega productos o servicios" action={<Tag label={`${draftItems.length} ÍTEMS`} tone={draftItems.length ? "green" : "muted"} />} /><View style={quoteStyles.choiceStack}>{products.map((item) => <Pressable key={item.id} onPress={() => { materializeEdit(); setProductId(item.id); }} style={[quoteStyles.productOption, product?.id === item.id && quoteStyles.productOptionSelected]}><View style={quoteStyles.productCopy}><Text style={quoteStyles.productName}>{item.name}</Text><Text style={quoteStyles.productMeta}>{item.category} · {item.unit}{item.taxRate ? ` · ${item.taxRate}% imp.` : ""}</Text></View><Text style={quoteStyles.productPrice}>{formatMoney(item.netPrice)}</Text></Pressable>)}</View>{product ? <View style={quoteStyles.controlsRow}><Counter label="Cantidad" value={quantity} onChange={setQuantity} minimum={1} /><Counter label="Descuento" value={selectedDiscount} onChange={(value) => { materializeEdit(); setDiscount(value); }} minimum={0} suffix="%" step={5} maximum={50} /></View> : null}<PrimaryButton label="Añadir del catálogo" icon="plus-circle-outline" onPress={addSelectedProduct} tone="quiet" disabled={!product} compact /><Pressable onPress={() => setManualOpen((current) => !current)} style={quoteStyles.manualToggle}><MaterialCommunityIcons name={manualOpen ? "chevron-up" : "playlist-edit"} size={17} color={biemColors.cyan} /><Text style={quoteStyles.manualToggleText}>Registro manual rápido</Text><Text style={quoteStyles.manualHint}>sin guardar</Text></Pressable>{manualOpen ? <View style={quoteStyles.manualBox}><TextInput value={manualName} onChangeText={setManualName} placeholder="Descripción del producto o servicio" placeholderTextColor={biemColors.muted} style={quoteStyles.manualInput} /><View style={quoteStyles.manualRow}><TextInput value={manualQuantity} onChangeText={setManualQuantity} keyboardType="decimal-pad" placeholder="Cantidad" placeholderTextColor={biemColors.muted} style={[quoteStyles.manualInput, quoteStyles.manualSmall]} /><TextInput value={manualPrice} onChangeText={setManualPrice} keyboardType="decimal-pad" placeholder="Precio base" placeholderTextColor={biemColors.muted} style={[quoteStyles.manualInput, quoteStyles.manualPriceInput]} /></View><View style={quoteStyles.manualTaxRow}><Text style={quoteStyles.manualTaxLabel}>Impuesto</Text><View style={quoteStyles.manualTaxOptions}>{[0, 5, 19].map((rate) => <Pressable key={rate} onPress={() => setManualTax(rate)} style={[quoteStyles.manualTaxChip, manualTax === rate && quoteStyles.manualTaxChipActive]}><Text style={[quoteStyles.manualTaxText, manualTax === rate && quoteStyles.manualTaxTextActive]}>{rate === 0 ? "Sin impuesto" : `${rate}%`}</Text></Pressable>)}</View></View><PrimaryButton label="Añadir ítem manual" icon="check" onPress={addManualItem} compact /></View> : null}</Surface>

    <Surface style={quoteStyles.cartCard}><SectionTitle title="Ítems de la propuesta" />{draftItems.length ? <View style={quoteStyles.cartList}>{draftItems.map((item) => <View key={item.productId} style={quoteStyles.cartItem}><View style={quoteStyles.cartCopy}><View style={quoteStyles.cartTitleRow}><Text style={quoteStyles.cartName}>{item.name}</Text>{item.source === "manual" ? <Tag label="MANUAL" tone="amber" /> : null}</View><Text style={quoteStyles.cartMeta}>{item.quantity} × {formatMoney(item.unitPrice)}</Text></View><View style={quoteStyles.cartValueWrap}><Text style={quoteStyles.cartValue}>{formatMoney(item.unitPrice * item.quantity)}</Text><Pressable onPress={() => removeItem(item.productId)}><Text style={quoteStyles.removeText}>Quitar</Text></Pressable></View></View>)}</View> : <View style={quoteStyles.emptyCart}><MaterialCommunityIcons name="cart-outline" size={20} color={biemColors.muted} /><Text style={quoteStyles.emptyCartText}>Aún no hay ítems. Elige del catálogo o escribe uno manualmente.</Text></View>}</Surface>

    <Surface style={quoteStyles.previewCard}><View style={quoteStyles.previewHeader}><View><Text style={quoteStyles.previewKicker}>VISTA PREVIA</Text><Text style={quoteStyles.previewTitle}>{business.name}</Text></View><Tag label={latestQuote?.number ?? "BORRADOR"} tone="cyan" /></View><View style={quoteStyles.docLine} /><Text style={quoteStyles.toLabel}>PARA</Text><Text style={quoteStyles.toName}>{client?.company || client?.name || "Cliente por definir"}</Text><View style={quoteStyles.documentItems}>{draftItems.length ? draftItems.map((item) => <View key={item.productId} style={quoteStyles.documentItem}><View style={quoteStyles.documentItemCopy}><Text style={quoteStyles.documentItemName}>{item.name}</Text><Text style={quoteStyles.documentItemMeta}>{item.quantity} × {formatMoney(item.unitPrice)}</Text></View><Text style={quoteStyles.documentItemValue}>{formatMoney(item.unitPrice * item.quantity)}</Text></View>) : <Text style={quoteStyles.previewEmpty}>Añade productos para ver el desglose.</Text>}</View><View style={quoteStyles.totalsArea}><ValueRow label="Subtotal" value={formatMoney(totals.subtotal)} /><ValueRow label={`Descuento ${selectedDiscount ? `${selectedDiscount}%` : ""}`} value={`− ${formatMoney(totals.discountAmount)}`} /><ValueRow label="Impuestos" value={formatMoney(totals.tax)} /><View style={quoteStyles.totalLine} /><ValueRow label="TOTAL" value={formatMoney(totals.total)} accent /></View><PrimaryButton label={editSource ? "Guardar cambios" : "Generar cotización"} icon="file-document-check-outline" onPress={makeQuote} disabled={!draftItems.length} /><Text style={quoteStyles.validity}>Vigencia: {business.validityDays} días · puedes completarla después</Text></Surface>

    {documentQuote ? <Surface style={quoteStyles.actionsCard}><SectionTitle title="Cotización lista" action={<Tag label={documentQuote.status.toUpperCase()} tone={documentQuote.status === "Enviada" ? "amber" : documentQuote.status === "Aprobada" || documentQuote.status === "Completada" ? "green" : "muted"} />} /><Text style={quoteStyles.actionsText}>Descarga, comparte o marca el trabajo como enviado.</Text><View style={quoteStyles.actionGrid}><PrimaryButton label={exporting ? "Generando…" : "Generar PDF"} icon="file-pdf-box" onPress={() => exportPdf(false)} tone="quiet" disabled={exporting} /><PrimaryButton label="Compartir propuesta" icon="share-variant-outline" onPress={() => exportPdf(true)} disabled={exporting} /></View><View style={quoteStyles.actionRow}><Pressable onPress={() => { updateQuoteStatus(documentQuote.id, "Enviada"); setLatestQuote({ ...documentQuote, status: "Enviada" }); setFeedback("Marcada como enviada."); }} style={quoteStyles.smallAction}><MaterialCommunityIcons name="send-outline" size={16} color={biemColors.cyan} /><Text style={quoteStyles.smallActionText}>Marcar enviada</Text></Pressable><Pressable onPress={() => router.push("/historial")} style={quoteStyles.smallAction}><MaterialCommunityIcons name="history" size={16} color={biemColors.muted} /><Text style={quoteStyles.smallActionText}>Ver historial</Text></Pressable></View></Surface> : null}
    {feedback ? <Text style={quoteStyles.feedback}>{feedback}</Text> : null}
  </ScrollView></BiemScreen>;
}

function Counter({ label, value, onChange, suffix = "", minimum, maximum = 99, step = 1 }: { label: string; value: number; onChange: (value: number) => void; suffix?: string; minimum: number; maximum?: number; step?: number }) { return <View style={quoteStyles.counterWrap}><Text style={quoteStyles.counterLabel}>{label}</Text><View style={quoteStyles.counterBox}><Pressable onPress={() => onChange(Math.max(minimum, value - step))} style={quoteStyles.counterAction}><MaterialCommunityIcons name="minus" size={16} color={biemColors.text} /></Pressable><Text style={quoteStyles.counterValue}>{value}{suffix}</Text><Pressable onPress={() => onChange(Math.min(maximum, value + step))} style={quoteStyles.counterAction}><MaterialCommunityIcons name="plus" size={16} color={biemColors.text} /></Pressable></View></View>; }
function quoteItemFromProduct(product: Product, quantity: number): QuoteItem { return { productId: product.id, name: product.name, quantity, unit: product.unit, unitPrice: product.netPrice, taxRate: product.taxRate, source: "catalog" }; }
function quoteTotals(items: QuoteItem[], discount: number) { const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0); const discountAmount = subtotal * discount / 100; const tax = items.reduce((sum, item) => sum + (item.unitPrice * item.quantity * (1 - discount / 100) * item.taxRate) / 100, 0); return { subtotal, discountAmount, tax, total: subtotal - discountAmount + tax }; }
function quoteHtml(quote: Quote, client: Client | undefined, business: ReturnType<typeof useBiem>["business"]) {
  const totals = quoteTotals(quote.items, quote.discount);
  const rows = quote.items.map((item) => `<tr><td>${escapeHtml(item.name)}<br/><small>${item.quantity} × ${formatMoney(item.unitPrice)}</small></td><td style="text-align:right">${formatMoney(item.unitPrice * item.quantity)}</td></tr>`).join("");
  const logoUrl = safeLogoUrl(business.logoUrl);
  const logo = logoUrl ? `<img src="${escapeHtml(logoUrl)}" alt="Logo" style="width:52px;height:52px;object-fit:contain;vertical-align:middle;margin-right:12px"/>` : "";
  const clientName = client?.company || client?.name || "Cliente por definir";
  const clientContact = client?.name || "Datos del cliente pendientes";
  const conditions = escapeHtml(quote.conditions).replace(/\n/g, "<br/>");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/><style>body{font-family:Arial,sans-serif;color:#13233b;padding:42px}h1{font-size:28px;margin:0;color:#0b3a58;display:inline-block;vertical-align:middle}.top{display:flex;justify-content:space-between;border-bottom:2px solid #0b78b5;padding-bottom:22px}.muted{color:#63748c}.badge{background:#e3f4fc;color:#075985;border-radius:14px;padding:7px 11px;font-weight:700}table{width:100%;border-collapse:collapse;margin:30px 0}td{padding:14px 0;border-bottom:1px solid #dce4ed}small{color:#63748c}.total{margin-left:auto;width:250px}.row{display:flex;justify-content:space-between;padding:7px 0}.grand{font-size:20px;font-weight:800;border-top:2px solid #0b78b5;padding-top:12px;margin-top:6px}.footer{margin-top:44px;padding-top:20px;border-top:1px solid #dce4ed;font-size:12px;color:#63748c;line-height:1.5}</style></head><body><div class="top"><div>${logo}<h1>${escapeHtml(business.name)}</h1><p class="muted">${escapeHtml(business.email)}<br/>${escapeHtml(business.phone)} · ${escapeHtml(business.city)}</p></div><div style="text-align:right"><span class="badge">${escapeHtml(quote.number)}</span><p class="muted">Emitida: ${formatDate(quote.issuedAt)}<br/>Vigente hasta: ${formatDate(quote.validUntil)}</p></div></div><h2>Propuesta para ${escapeHtml(clientName)}</h2><p class="muted">${escapeHtml(clientContact)}<br/>${escapeHtml(client?.email || "")}</p><table><tbody>${rows}</tbody></table><div class="total"><div class="row"><span>Subtotal</span><span>${formatMoney(totals.subtotal)}</span></div><div class="row"><span>Descuento</span><span>− ${formatMoney(totals.discountAmount)}</span></div><div class="row"><span>Impuestos</span><span>${formatMoney(totals.tax)}</span></div><div class="row grand"><span>Total</span><span>${formatMoney(totals.total)}</span></div></div><div class="footer"><strong>Condiciones comerciales</strong><br/>${conditions}<br/><br/>Gracias por considerar esta propuesta.</div></body></html>`;
}

function safeLogoUrl(value: string) { return /^https?:\/\//i.test(value) ? value : ""; }
function escapeHtml(value: string) { return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character] ?? character); }

const quoteStyles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 112, gap: 14 }, header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, eyebrow: { color: biemColors.cyan, fontSize: 10, letterSpacing: 1.6, fontWeight: "900" }, title: { color: biemColors.text, fontSize: 28, lineHeight: 33, fontWeight: "900", letterSpacing: -0.8, marginTop: 3 }, lead: { color: biemColors.muted, fontSize: 14, lineHeight: 20, marginTop: -5 }, quickNote: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 12, backgroundColor: biemColors.cyanSoft, borderColor: "#B9E3F5" }, quickNoteText: { color: biemColors.muted, flex: 1, fontSize: 12 }, quickNoteStrong: { color: biemColors.text, fontWeight: "900" }, formCard: { gap: 9 }, choiceStack: { gap: 8 }, clientOption: { borderRadius: 13, borderWidth: 1, borderColor: biemColors.line, padding: 11, backgroundColor: biemColors.surface, flexDirection: "row", alignItems: "center", gap: 10 }, clientOptionSelected: { borderColor: biemColors.cyan, backgroundColor: biemColors.cyanSoft }, clientAvatar: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: biemColors.cyanSoft }, clientAvatarText: { color: biemColors.cyan, fontWeight: "900" }, clientCopy: { flex: 1, gap: 2 }, clientCompany: { color: biemColors.text, fontSize: 13, fontWeight: "900" }, clientMeta: { color: biemColors.muted, fontSize: 10 }, productOption: { borderRadius: 13, borderWidth: 1, borderColor: biemColors.line, padding: 12, backgroundColor: biemColors.surface, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, productOptionSelected: { borderColor: biemColors.cyan, backgroundColor: biemColors.cyanSoft }, productCopy: { flex: 1, gap: 2 }, productName: { color: biemColors.text, fontSize: 13, fontWeight: "900" }, productMeta: { color: biemColors.muted, fontSize: 10 }, productPrice: { color: biemColors.cyan, fontSize: 13, fontWeight: "900" }, controlsRow: { flexDirection: "row", gap: 12, marginTop: 3 }, counterWrap: { flex: 1, gap: 6 }, counterLabel: { color: biemColors.muted, fontSize: 10, textTransform: "uppercase", letterSpacing: 0.6, fontWeight: "800" }, counterBox: { minHeight: 42, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: biemColors.ink, borderWidth: 1, borderColor: biemColors.line, borderRadius: 12, paddingHorizontal: 3 }, counterAction: { width: 33, height: 33, alignItems: "center", justifyContent: "center" }, counterValue: { color: biemColors.text, fontSize: 13, fontWeight: "900" }, manualToggle: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 6 }, manualToggleText: { color: biemColors.cyan, fontSize: 12, fontWeight: "900" }, manualHint: { color: biemColors.muted, fontSize: 10, marginLeft: "auto" }, manualBox: { gap: 8, padding: 11, backgroundColor: biemColors.cyanSoft, borderRadius: 13 }, manualRow: { flexDirection: "row", gap: 8 }, manualInput: { minHeight: 43, paddingHorizontal: 11, borderRadius: 11, borderWidth: 1, borderColor: "#B9E3F5", backgroundColor: biemColors.surface, color: biemColors.text, fontSize: 12, flex: 1 }, manualSmall: { flex: 0.7 }, manualPriceInput: { flex: 1.3 }, manualTaxRow: { gap: 6 }, manualTaxLabel: { color: biemColors.muted, fontSize: 10, textTransform: "uppercase", letterSpacing: 0.6, fontWeight: "800" }, manualTaxOptions: { flexDirection: "row", gap: 7 }, manualTaxChip: { paddingVertical: 7, paddingHorizontal: 10, borderRadius: 9, backgroundColor: biemColors.surface }, manualTaxChipActive: { backgroundColor: "#B9E3F5" }, manualTaxText: { color: biemColors.muted, fontSize: 10, fontWeight: "800" }, manualTaxTextActive: { color: biemColors.cyan }, cartCard: { gap: 8, paddingVertical: 14 }, cartList: { gap: 7 }, cartItem: { paddingHorizontal: 10, paddingVertical: 10, borderRadius: 12, backgroundColor: biemColors.ink, borderColor: biemColors.line, borderWidth: 1, flexDirection: "row", gap: 10 }, cartCopy: { flex: 1, gap: 4 }, cartTitleRow: { flexDirection: "row", alignItems: "center", gap: 6 }, cartName: { color: biemColors.text, fontSize: 12, fontWeight: "900", flexShrink: 1 }, cartMeta: { color: biemColors.muted, fontSize: 10 }, cartValueWrap: { alignItems: "flex-end", gap: 4 }, cartValue: { color: biemColors.cyan, fontSize: 12, fontWeight: "900" }, removeText: { color: biemColors.red, fontSize: 10, fontWeight: "900" }, emptyCart: { minHeight: 47, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 4 }, emptyCartText: { color: biemColors.muted, fontSize: 11, flex: 1, lineHeight: 16 }, previewCard: { gap: 11, backgroundColor: "#FFFFFF", borderColor: "#C9D9E8" }, previewHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }, previewKicker: { color: "#4C647E", fontSize: 9, letterSpacing: 1.1, fontWeight: "900" }, previewTitle: { color: "#10263F", fontSize: 17, fontWeight: "900", marginTop: 2 }, docLine: { height: 2, backgroundColor: biemColors.cyan }, toLabel: { color: "#4C647E", fontSize: 9, fontWeight: "900", letterSpacing: 1 }, toName: { color: "#10263F", fontWeight: "900", fontSize: 16, marginTop: -6 }, documentItems: { borderTopWidth: 1, borderColor: "#D2DAE7", marginTop: 4 }, documentItem: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 11, borderBottomWidth: 1, borderColor: "#D2DAE7" }, documentItemCopy: { flex: 1, gap: 2 }, documentItemName: { color: "#10263F", fontSize: 12, fontWeight: "800" }, documentItemMeta: { color: "#61748D", fontSize: 10 }, documentItemValue: { color: "#10263F", fontSize: 13, fontWeight: "900" }, previewEmpty: { color: "#61748D", fontSize: 11, paddingVertical: 12 }, totalsArea: { paddingVertical: 2 }, totalLine: { height: 1, backgroundColor: "#D2DAE7", marginVertical: 2 }, validity: { color: "#61748D", textAlign: "center", fontSize: 10, marginTop: -4 }, actionsCard: { gap: 12 }, actionsText: { color: biemColors.muted, fontSize: 12, lineHeight: 18, marginTop: -7 }, actionGrid: { gap: 8 }, actionRow: { flexDirection: "row", gap: 16, paddingTop: 2 }, smallAction: { flexDirection: "row", alignItems: "center", gap: 5 }, smallActionText: { color: biemColors.muted, fontSize: 11, fontWeight: "800" }, feedback: { color: biemColors.green, textAlign: "center", fontSize: 12, fontWeight: "800", marginTop: 2 },
});
